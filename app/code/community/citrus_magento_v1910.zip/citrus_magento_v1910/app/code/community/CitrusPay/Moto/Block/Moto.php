<?php
class CitrusPay_Moto_Block_Moto extends Mage_Core_Block_Template
{
  // necessary methods
}
